import 'package:flutter/cupertino.dart';

class DetailScreenArgument {
  final String machineName;
  final Widget body;

  DetailScreenArgument(this.machineName, this.body);
}