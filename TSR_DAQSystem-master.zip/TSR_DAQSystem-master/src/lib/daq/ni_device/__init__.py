from .ni_device import NIDevice
